import { useState } from 'react';
import './App.css';
import { 
  createUserWithEmailAndPassword, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  signOut } from 'firebase/auth';
import { auth } from './firebase-config';
import Container from './components/Container/container';

function App() {

  const [registerEmail, setRegisterEmail] = useState("")
  const [registerPassword, setRegisterPassword] = useState("")
  const [loginEmail, setLoginEmail] = useState("")
  const [loginPassword, setLoginPassword] = useState("")

  const [user, setUser] = useState({});

  onAuthStateChanged(auth, (currentUser) => {
    setUser(currentUser);
  })

  const register = () => {
    try { 
      const user = createUserWithEmailAndPassword(auth, registerEmail, registerPassword)
      console.log(user);
    } catch (error) {
      console.log(error.message, 'Fail !')
    }
  }

  const login = () => {
    try { 
      const user = signInWithEmailAndPassword(auth, loginEmail, loginPassword)
      console.log(user);
    } catch (error) {
      console.log(error.message, 'Fail !')
    }
  }

  const [show, setShow] = useState(true)

  return (
    <div className="App">
      {
      show ? <Container/> : null
      }
      <div className='centerTitle'>
        <h1>Bienvenue sur Linx !</h1>
      </div>

      <div className='connection'>
        <form className='marge-right'>
          <h3>Inscription</h3>
          <label htmlFor='email'>Email :</label>
          <input size={25} maxLength={50} required onChange={(event) => {setRegisterEmail(event.target.value);}} className='input'/>
      
          <label htmlFor='password'>Mot de passe :</label>
          <input size={25} minLength={8} required onChange={(event) => {setRegisterPassword(event.target.value);}} className='input' />
          <button onClick={register} className='validbtn' >S'inscrire</button>
        </form>
        
        <form>
          <h3>Connexion</h3>

          <label htmlFor='email'>Email :</label>
          <input size={25} maxLength={50} required onChange={(event) => {setLoginEmail(event.target.value);}} className='input'/>

          <label htmlFor='password'>Mot de passe :</label>
          <input size={25} minLength={8} required onChange={(event) => {setLoginPassword(event.target.value);}} className='input'/>
          <button onClick={login} className='validbtn'>Se connecter</button>
        </form>

        {/* <h4>Connecté</h4>
        {user?.email}
        <button onClick={logout}>Se déconnecter</button> */}
      </div>
    </div>
  );
}

export default App;