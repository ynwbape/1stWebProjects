import HeaderLinx from "../Header/header";
import Main from "../Main/main";

const Container = () => {
    return ( 
        <>
        <HeaderLinx />
        <Main /> 
        </>
     );
}
 
export default Container;