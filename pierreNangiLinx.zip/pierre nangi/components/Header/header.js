import React from 'react';

const HeaderLinx = () => {
    return ( 
        <header id='' className='header'>
            <span id='username' className='span'>LINX</span>
        </header>
     );
}
 
export default HeaderLinx;