import React, { Component } from 'react'
import image from '../../../../../assets/closedCross.svg'

export default class Card extends Component {
    constructor() {
        super()
        this.state = {
            formArray: []
        }
      }
    
      createCard() {
          const forms = this.state.formArray;
          const title = '';
          const URL = '';
          const text = '';
          forms.push({title, URL, text});
          this.setState({formArray: forms })
      }
      
    render() {
        return (
            <div id='card' className='card'>
                <div className='halfLeft'>
                    <h1>title</h1>

                    <a id='cardLink' href='https://genius.com/' className='cardlink' target='_blank' rel='noopener noreferrer'>URL</a>  

                    <p id='textarea' className='description'>
                        Test de texte aléatoire sheeeeesh
                    </p>
                </div>

                <div id='closeCrx' className='closedCross'>
                    <button id='test' className='closeBtn'>
                        <img src={image} alt='Cross to represent "close"'/>
                    </button>
                </div>
            </div>
        )
    };
}