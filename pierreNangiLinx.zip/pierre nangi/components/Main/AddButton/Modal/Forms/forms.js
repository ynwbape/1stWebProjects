import React, { Component } from 'react'

class Champs extends Component {
    render() {
        const {name, children, type} = this.props
        return (
            <>
                <label htmlFor={name}>{children}</label>
                <input type={type} id={name} name={name} className='input'minLength={4} maxLength={100} size={25} required/> 
            </>
        )
    }
}

class Resume extends Component {
    render() {
        const {name, children} = this.props
        return (
            <>
                <label htmlFor={name}>{children}</label>
                <textarea id={name} name={name} className='textarea' rows={4} cols={78} minLength={4} maxLength={6000} wrap='true' required/>
            </>
        )
    }
}   

export class Forms extends Component {

    constructor(props) {
        super(props)
        this.state = {
            title: '',
            url: '',
            resume: '',
        }
        this.handleSubmit = this.handleSubmit.bind(this)
    }
    
    handleSubmit(e) {
        e.preventDefault();
        const data = JSON.stringify(this.state)
        console.log(data)
    }
    render() {
        return (
            <form method='POST' id='form' className='form' onSubmit={this.handleSubmit}>
    
                <Champs type="text" name="title">Title</Champs>
                
                <Champs type="url" name="url" pattern="https://.*">URL</Champs>
                
                <Resume name="resume">Description</Resume>
                
                <button id='validate' className='validbtn' type='submit'>Apply</button>
            </form>
    )
  }

}