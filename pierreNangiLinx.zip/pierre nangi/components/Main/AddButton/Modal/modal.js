import React from 'react'
import { Forms } from './Forms/forms'

export default function Modal(props) {
  return (
    <div className='Modal'
        style={{
            transform: props.visible ? 'translateX(0vw)' : 'translateX(100vw)',
            opacity: props.visible ? '1' : '0'
        }}
        >
        <button onClick={props.cache} className='closebtn'>
            <span>x</span>    
        </button>
        
        <Forms />
    </div>
  )
}



