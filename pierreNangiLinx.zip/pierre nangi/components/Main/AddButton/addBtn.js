import React, { Component } from 'react';
import image from '../../../assets/addcrossbtn.svg.svg'
import Modal from './Modal/modal';

export default class AddButton extends Component {
    state = {
        visible: false
    }

    montre = () => {
        this.setState({
            visible: true
        })
    }

    cache = () => {
        this.setState({
            visible: false
        })
    }

    render() {
        return ( 
            <> 
                <button onClick={this.montre} className='addBtn'>
                    <img src={image} alt='Cross to represent "add"'/>
                </button>

                <Modal
                visible={this.state.visible}
                cache={this.cache}
                />
            </>
         );
    }
}