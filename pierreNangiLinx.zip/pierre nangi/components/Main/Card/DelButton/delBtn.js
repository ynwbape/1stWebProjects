import React from 'react';

const DelButton = () => {
    return (  );
}
 
export default DelButton;