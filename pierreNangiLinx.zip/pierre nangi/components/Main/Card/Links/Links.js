import React from 'react';

const Links = () => {
    return ( 
        <div id='' className='links'>
        </div>
     );
}
 
export default Links;