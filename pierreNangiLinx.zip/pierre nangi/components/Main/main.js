import React from 'react';
import AddButton from './AddButton/addBtn';

const Main = () => {
    return ( 
        <div className='main'>
            <AddButton />
        </div>
     );
}
 
export default Main;