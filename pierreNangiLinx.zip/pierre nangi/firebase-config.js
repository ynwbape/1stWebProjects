import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseconfig = {
    apiKey: "AIzaSyDkjA5VZwq9QQUCCa4Q0JHf97tGmojto98",
    authDomain: "linkpierre.firebaseapp.com",
    databaseURL: "https://linkpierre-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "linkpierre",
    storageBucket: "linkpierre.appspot.com",
    messagingSenderId: "647184451536",
    appId: "1:647184451536:web:fdf2fa7cb42bd20ddddbd5"
  };

const app = initializeApp(firebaseconfig);

export const auth = getAuth(app);