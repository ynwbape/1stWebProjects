const flècheBas = document.querySelector("#arrowDown")
let click = false
function Descente() {
    flècheBas.addEventListener('click', () => {
    if (click == true) {document.body.animate([
        { transform: 'translateY(0vh)' },
        { transform: 'translateY(-100vh)' }
    ])}
})
}